<?php
session_start();

$message = "";

if (isset($_GET["registered"])) {
    $message = "Registration successful. Please login.";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    if (
        isset($_SESSION["registered_user"]) &&
        $_SESSION["registered_user"]["email"] === $email &&
        password_verify($password, $_SESSION["registered_user"]["password"])
    ) {

        $_SESSION["logged_in"] = true;

        header("Location: portfolio.php");
        exit;

    } else {

        $message = "Invalid email or password.";

    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Login | StockMart</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="css/style.css">

</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark">
<img src="assets/logo.png" class="navbar-logo">

    <div class="ms-3">

        <h5 class="mb-0 fw-bold">

            StockMart

        </h5>

        <small>

            Your Market, Your Edge

        </small>

    </div>

</div>

</div>

</nav>

<div class="container py-5" style="max-width:600px;">

<div class="stock-card">

<h2 class="text-center mb-4">

Welcome Back

</h2>

<?php if($message!=""){ ?>

<div class="alert alert-info">

<?= $message ?>

</div>

<?php } ?>

<form method="POST">

<div class="mb-3">

<label class="form-label">

Email

</label>

<input
type="email"
name="email"
class="form-control"
required>

</div>

<div class="mb-4">

<label class="form-label">

Password

</label>

<input
type="password"
name="password"
class="form-control"
required>

</div>

<button class="btn btn-success w-100">

Login

</button>

</form>

<hr>

<p class="text-center">

Don't have an account?

<a href="register.php">

Register

</a>

</p>

</div>

</div>

</body>

</html>