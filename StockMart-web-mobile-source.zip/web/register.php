<?php
session_start();

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    $confirm = trim($_POST["confirm"]);

    if ($password !== $confirm) {

        $message = "Passwords do not match.";

    } else {

        $_SESSION["registered_user"] = [

            "name" => $name,
            "email" => $email,
            "password" => password_hash($password, PASSWORD_DEFAULT)

        ];

        header("Location: login.php?registered=1");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Register | StockMart</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="css/style.css">

</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark">
<img src="assets/logo.png" class="navbar-logo">

    <div class="ms-3">

        <h5 class="mb-0 fw-bold">

            StockMart

        </h5>

        <small>

            Your Market, Your Edge

        </small>

    </div>

</div>
</nav>

<div class="container">


<div class="container py-5" style="max-width:600px;">

<div class="stock-card">

<h2 class="text-center mb-4">

Create Account

</h2>

<?php if($message!=""){ ?>

<div class="alert alert-danger">

<?= $message ?>

</div>

<?php } ?>

<form method="POST">

<div class="mb-3">

<label class="form-label">

Full Name

</label>

<input
type="text"
name="name"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">

Email

</label>

<input
type="email"
name="email"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">

Password

</label>

<input
type="password"
name="password"
class="form-control"
required>

</div>

<div class="mb-4">

<label class="form-label">

Confirm Password

</label>

<input
type="password"
name="confirm"
class="form-control"
required>

</div>

<button
class="btn btn-success w-100">

Register

</button>

</form>

<hr>

<p class="text-center">

Already have an account?

<a href="login.php">

Login

</a>

</p>

</div>

</div>

</body>

</html>